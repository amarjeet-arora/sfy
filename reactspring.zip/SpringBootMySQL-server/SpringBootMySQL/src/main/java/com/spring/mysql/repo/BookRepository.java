package com.spring.mysql.repo;

import org.springframework.data.repository.CrudRepository;

import com.spring.mysql.model.Book;

public interface BookRepository extends CrudRepository<Book, Long> {

}
