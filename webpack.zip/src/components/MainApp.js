import React,{ Component } from "react";

export default class MainApp extends Component {

render(){

    return (
        <div>
            <h2> welcome to webpack</h2>
        </div>
    )
}

}